#!/usr/bin/env python
# Copyright (c) 2002-2020 ActiveState Software Inc.  All rights reserved.

"""ActivePython identification module

This can be run as a script to dump version info:
    python .../activestate.py
or to relocate this Python installation appropriately (see relocate_python()
for details):
    python .../activestate.py --relocate
"""

import os
import re
import sys
from os.path import isabs, join, splitext

#---- ActivePython build/configuration info

version = "2.7.16.0000";
version_info = {
'build_host': 'ActiveStates-Mac-3.local', 
'build_plat_name': 'win32', 
'platname': 'win32', 
'compiler': 'App', 
'pywin32_build' : 'None', 
'pywin32_src' : 'None', 
'pywin32_ver' : 'None', 
'with_sqlite3' : 'False', 
'with_pywin32' : 'False', 
'with_docs' : 'False', 
'with_bzip2' : 'False', 
'with_bsddb' : 'False', 
'with_ssl' : 'False', 
'with_ctypes' : 'True', 
'with_tcltk' : 'False', 
'zlib_ver' : '(1, 2, 8)',
'platinfo' : { 'arch' : '',
	'distro' : 'Windows',
	'distro_desc' : 'Windows 7',
	'distro_ver' : '7',
	'name' : 'win32',
	'os' : 'darwin',
	'os_ver' : '17.7.0',
},
'build_plat_fullname' : 'darwin17.7.0-Windows7-libc-1--1--',
'build_num' : '0000',
'python_src' : ('2.7.16', 'url', 's3://platform-sources/languages/01da813a3600876f03f46db11cc5c408175e99f03af2ba942ef324389a83bad5/Python-2.7.16.tgz'),
'with_tests' : 'False',
'product_type' : 'ActivePython'
};

compiler_info = """Apple LLVM version 10.0.0 (clang-1000.10.44.4)""";


# Used for Python install relocation.
prefixes = set([
    # Prefix to which extensions were built
    '/build/camel/work-padpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpad/local-lib',
    # Prefix to which Python sources were built.
    '/build/camel/work-padpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpad/local-lib',
    # Prefix to the Python image (sys.prefix)
    # (relied by pypm -- for relocation)
    '/build/camel/work-padpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpadpad/local-lib',
])
shortest_original_prefix_length = 91



#---- relocation code

def _is_path_binary(path):
    """Return true iff the given file is binary.

    Raises an EnvironmentError if the file does not exist or cannot be
    accessed.
    """
    fin = open(path, 'rb')
    try:
        CHUNKSIZE = 1024
        while 1:
            chunk = fin.read(CHUNKSIZE)
            if '\0' in chunk: # found null byte
                return True
            if len(chunk) < CHUNKSIZE:
                break # done
    finally:
        fin.close()
    return False

def log(msg, verbose=False):
    if verbose:
        sys.stderr.write(msg+"\n")

def relocate_path(path, from_prefix, to_prefix, verbose=False):
    import sys
    import os
    from os.path import join
    import stat
    import re    

    # Determine if this file needs to be relocated.
    fin = open(path, 'rb')
    try:
        content = fin.read()
    finally:
        fin.close()

    is_binary = _is_path_binary(path)
    if is_binary:
        from_str = join(from_prefix, "lib")
        if version_info['platinfo']['os'] == "linux":
            rel_path = path.split(to_prefix, 1)[1]
            dot_dots = len(rel_path.split("/")) - 2
            to_str = "$ORIGIN/" + ( "../" * dot_dots ) + "lib"
        else:
            to_str = join(to_prefix, "lib") 
    else:
        from_str = from_prefix
        to_str = to_prefix

    if sys.version_info[0] >= 3:
        from_str = bytes(from_str, 'utf-8')
        to_str = bytes(to_str, 'utf-8')

    if from_str not in content:
        return

    # Relocate this file.
    log("relocate '%s'" % path, verbose)
    perm = stat.S_IMODE(os.stat(path).st_mode)
    if is_binary:
        if sys.platform.startswith("aix"):
            # On AIX the lib path _list_ is stored as one string, rather
            # than just the one path. This means that the integrity of
            # the path list must be maintained by separating with ':'.
            # We also change the remainder to all x's to ensure it is
            # a bogus path.
            to_str = join(to_prefix, "lib") \
                + ':' + "x"*(len(from_prefix)-len(to_prefix)-1)
            if sys.version_info[0] >= 3:
                to_str = bytes(to_str, 'utf-8')
            #log("replace (length %%d)\n\t%%s\nwith (length %%d)\n\t%%s",
            #    %% (len(from_str), from_str, len(to_str), to_str), verbose)
            content = content.replace(from_str, to_str)
        else:
            # Replace 'from_str' with 'to_str' in a null-terminated string.
            # Make sure to properly correct for trailing content in the
            # same string because:
            # - on HP-UX sometimes a full path to the shared lib is stored:
            #      <from_str>/libtcl8.4.sl\0
            # - on AIX a path _list_ is stored:
            #      <from_str>:other/lib/paths\0
            #   NOTE: This *should* work on AIX, AFAICT, but it does
            #   *not*. See above for special handling for AIX.
            #TODO: should this regex use re.DOTALL flag?
            pattern = re.compile(re.escape(from_str) + "([^\0]*)\0")
            def c_string_replace(match, before=from_str, after=to_str):
                lendiff = len(before) - len(after)
                s = after + match.group(1) + ("\0" * lendiff) + "\0"
                # Encode nulls as '0' instead of '\x00' so one can see
                # the before and after strings line up.
                #log("replace (length %%d)\n\t%%s\nwith (length %%d)\n\t%%s",
                #    %% (len(match.group(0)),
                #        repr(match.group(0)).replace("\\x00", '0'),
                #        len(s),
                #        repr(s).replace("\\x00", '0')), verbose)
                return s
            content = pattern.sub(c_string_replace, content)
    else:
        #log("replace (length %%d)\n\t%%s\nwith (length %%d)\n\t%%s",
        #    %% (len(from_str), from_str, len(to_str), to_str), verbose)
        content = content.replace(from_str, to_str)
    # Sometimes get the following error. Avoid it by removing file first.
    #   IOError: [Errno 26] Text file busy: '$path'
    os.remove(path)
    fout = open(path, 'wb')
    try:
        fout.write(content)
    finally:
        fout.close()
    os.chmod(path, perm) # restore permissions


def _rewrite_shebang(path, install_prefix):
    top_path = path.split(install_prefix, 1)[1].split("/")[1]

    if top_path == "bin":
        if _is_path_binary(path):
            return
    elif splitext(path)[1] != ".py":
        return
    # There are some files that are not in UTF-8. We need to load this as
    # binary data but then convert it to UTF-8 to run a regex against it.
    fin = open(path, 'rb')
    try:
        first = fin.readline()
        rest = fin.read()
    finally:
        fin.close()

    try:
        if not re.search("^\#\!/.+python.*$", first.decode("utf-8")):
            return
    except:
        return

    first = "#!/usr/bin/env python"
    if sys.version_info[0] >= 3:
        first += str(sys.version_info[0])
    first += "\n"

    fin = open(path, 'wb')
    try:
        fin.write(first.encode() + rest)
    finally:
        fin.close()

def relocate_python(install_prefix, verbose=False, useEnv=False):
    """Relocate this Python installation.
    
    "Relocation" involves updating hardcoded shebang lines in Python scripts
    and (on some platforms) binary patching of built-in runtime-lib-paths
    to point to the given install prefix.
    """
    
    assert isabs(install_prefix)

    log("relocate this Python to '%s'" % install_prefix, verbose)
    for prefix in prefixes:
        if prefix == install_prefix:
            continue
        for dirpath, dirnames, filenames in os.walk(install_prefix):
            for filename in filenames:
                if splitext(filename)[1] in (".pyo", ".pyc"):
                    continue
                fullPath = join(dirpath, filename)
                relocate_path(fullPath, prefix, install_prefix, verbose)
                if useEnv and not sys.platform.startswith("win"):
                    _rewrite_shebang(fullPath, install_prefix)


#---- mainline

if __name__ == "__main__":
    if "--relocate" in sys.argv:
        # Determine the install_prefix holding this module and relocate
        # that Python installation.
        if sys.platform == "win32":
            raise RuntimeError("relocating a Python install isn't "
                               "necessary on Windows")

        # <prefix>\lib\pythonX.Y\site-packages\activestate.py
        from os.path import dirname, exists, join, basename, abspath
        install_prefix = dirname(dirname(dirname(dirname(abspath(__file__)))))
        python_exe = join(install_prefix, "bin", "python")
        if not exists(python_exe):
            raise RuntimeError("'%s' does not exist: it doesn't look like "
                               "'%s' is in a Python site-packages dir"
                               % (python_exe, basename(__file__)))
        del python_exe, dirname, exists, join, basename, abspath
        
        relocate_python(install_prefix, True)

    else:
        for key, value in sorted(version_info.items()):
            if value is None: continue
            if key.endswith("_src"): continue
            if key in ("platinfo", "configuration"): continue
            print("%s: %s" % (key, value))
    
