#!/usr/bin/env python
print '#coding=0'
